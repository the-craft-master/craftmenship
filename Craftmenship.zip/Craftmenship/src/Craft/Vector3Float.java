/*
 * Nathaniel Dao
 * Scott Ha
 * Andrew Lee
 * Jeffrey Nguyen
 * 
 */
package Craft;

public class Vector3Float {
    public float x, y, z;
    public Vector3Float(int x, int y, int z)
    {
        this.x=x; this.y=y; this.z=z;
    }    
}
